module.exports = {
  plugins: {
    tailwindcss: {}, // This plugin processes Tailwind directives
    autoprefixer: {}, // This plugin adds vendor prefixes for broader browser support
  },
};
